import pandas as pd
from sklearn.cluster import DBSCAN
import seaborn as sns
import  matplotlib.pyplot as plt
#read the file
df = pd.read_csv("accidental-deaths-in-usa-monthly.csv")
print(df.head())

#Convert 'Month' column to datetime
df['Month'] = pd.to_datetime(df['Month'], format='%Y-%m')

print(df)
df['year'] = df['Month'].dt.year
df['month'] = df['Month'].dt.month
df.drop(columns=['Month'], inplace=True)  # Remove original column if not needed

print(df)
# change the renmae to 'Accidental deaths in USA: monthly, 1973 ? 1978'
df.rename(columns={'Accidental deaths in USA: monthly, 1973 ? 1978':'deaths in usa'},inplace=True)
print(df.head(10))
#new dataframe
new_dataframe = pd.DataFrame(df)
print(new_dataframe)
#find the data shape
print(df.shape)

sns.pairplot(df)
plt.show()

plt.figure(figsize=(10,5))
sns.countplot(df["year"])
plt.show()


x = new_dataframe.iloc[:,[0,1]].values
print(x)
# model
db=DBSCAN(eps=2,min_samples=4,metric='euclidean')


model=db.fit(x)
print(model)

final_label = model.labels_
print(final_label)
#
unique_data = len(list(set(final_label)))
print(unique_data)

plt.scatter(x[:, 0],x[:, 1], c=final_label, cmap='viridis', edgecolor='k')
plt.xlabel('x')
plt.ylabel('y')
plt.title('DBSCAN Clustering Results')
plt.colorbar(label='Cluster Label')
plt.show()