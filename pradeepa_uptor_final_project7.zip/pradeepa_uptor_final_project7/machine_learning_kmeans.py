import pandas
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
# read the csv file
data= pandas.read_csv("Amazon stock data 2000-2025.csv", date_parser=['date'])
print(data)
print(data.dtypes)

data.set_index("date",inplace=True)
print(data)
# find the column names from dataset
data_columns =data.columns
print(data_columns)
# MinMaxScaler used for model accuracy
min_max_object = MinMaxScaler()
x_scaled = min_max_object.fit_transform(data)
# new dataframe
x = pandas.DataFrame(x_scaled,columns=[data.columns])
print(x.head())
# import the kmeans model
kmean_obj = KMeans(n_clusters=2, random_state=42)
fitted_model = kmean_obj.fit_predict(x)

# visualization
plt.figure(figsize=(10,6))
plt.scatter(x.iloc[:,1],x.iloc[:,2], c=fitted_model, cmap="rainbow", marker="*",label = "kmeans")
plt.legend()
plt.show()