import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder,StandardScaler

df =pd.read_csv("bank.csv")
print(df.head)


df.drop(["default","contact","campaign","pdays","previous","poutcome"], axis=1 ,inplace=True)

column_names = df.columns
print(column_names)

# convert cat data  to num data
le = LabelEncoder()
for columns in ["deposit","month","housing","loan","marital","education","job"]:
    df[columns] = le.fit_transform(df[columns])
    print(df[columns])


X = df[["job","education","loan"]]
y = df["housing"]
# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X,y ,test_size=0.2, random_state=42)

scaler_object  = StandardScaler()
x_scaler = scaler_object.fit_transform(X_train,y_train)
print(x_scaler)


#Create a k-NN classifier
knn= KNeighborsClassifier(n_neighbors=5,weights="distance",metric="euclidean")
#Fit the model to the training data
knn_model = knn.fit(X_train, y_train)
print(knn_model)
# # Make predictions on the test data
y_pred = knn.predict(X_test)
print(y_pred)
#
# # Calculate the accuracy of the model
accuracy = accuracy_score(y_test, y_pred)
print("accuracy_score",accuracy)
# """************************************************************************88"""
# import pandas as pd
# from sklearn.model_selection import train_test_split
# from sklearn.neighbors import KNeighborsRegressor
# from sklearn.metrics import mean_squared_error, root_mean_squared_error, mean_absolute_error
# from sklearn.preprocessing import LabelEncoder
#
#
#
# df =pd.read_csv("bank.csv")
# print(df.head)
#
#
# df.drop(["default","contact","campaign","pdays","previous","poutcome"], axis=1 ,inplace=True)
#
# column_names = df.columns
# print(column_names)
#
# # convert cat data  to num data
# le = LabelEncoder()
# for columns in ["deposit","month","housing","loan","marital","education","job"]:
#     df[columns] = le.fit_transform(df[columns])
#     print(df[columns])
#
#
# X = df[["job","deposit","education"]]
# y = df["housing"]
# # Split the data into training and test sets
# X_train, X_test, y_train, y_test = train_test_split(X,y ,test_size=0.2, random_state=42)
#
# # Create a k-NN regression model
# knn = KNeighborsRegressor()
#
# # Fit the model to the training data
# knn.fit(X_train, y_train)
#
# # Evaluate the model on the test data
# y_pred = knn.predict(X_test)
# print("prediction:",y_pred)
# mse =  mean_squared_error(y_test, y_pred)
# print("repot_mse",mse)



