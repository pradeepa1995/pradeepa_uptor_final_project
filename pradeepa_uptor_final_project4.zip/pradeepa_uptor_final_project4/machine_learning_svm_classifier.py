from sklearn.preprocessing import LabelEncoder
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import pandas as pd

df = pd.read_csv("placementdata.csv")
print(df)

# convert cat data  to num data
le = LabelEncoder()
for columns in ["ExtracurricularActivities","PlacementTraining","PlacementStatus"]:
    df[columns] = le.fit_transform(df[columns])
    print(df[columns])

x = df[["Internships","Projects"]]
# x = df[["Internships"]]
y = df["PlacementStatus"]
# Split the dataset into training and test sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

# Create an SVM classifier with a linear kernel
clf = SVC(kernel='rbf',gamma='scale')

# Train the classifier on the training data
clf.fit(x_train, y_train)

# Make predictions on the test data

y_pred = clf.predict(x_test)
print("prediction:",y_pred)
# Evaluate the performance of the classifier
accuracy = accuracy_score(y_test, y_pred)
print("accuracy:",accuracy)

import matplotlib.pyplot as plt

plt.figure(figsize=(10,8))
plt.scatter(x_test["Projects"],y_test,color="blue", label="Actual data")
plt.scatter(x_test["Projects"],y_pred,color="red",label="predicted data",marker="x")
plt.xlabel("actual")
plt.ylabel("Predict")
plt.title("SVR for placementdata")
plt.grid()
plt.legend()
plt.show()