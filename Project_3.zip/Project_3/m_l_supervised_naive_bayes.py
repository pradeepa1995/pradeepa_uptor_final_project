import pandas as pd
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

#read the  file
df = pd.read_csv("HDHI Admission data.csv")
print(df.head(10))

# convert cat data  to num data
le = LabelEncoder()
for columns in ["GENDER","RURAL","TYPE OF ADMISSION-EMERGENCY/OPD"]:
    df[columns] = le.fit_transform(df[columns])
    print(df[columns])

# declear x and y from the model
x = df[["GENDER","RURAL","TYPE OF ADMISSION-EMERGENCY/OPD"]]
y = df["OUTCOME"]

# train and test for model
x_train, x_test, y_train, y_test = train_test_split(x,y ,test_size=0.2, random_state=42)


# Initialize and train model
gnb = GaussianNB()
gnb.fit(x_train, y_train)

# Make predictions
y_pred = gnb.predict(x_test)

# Evaluate model
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy:",accuracy)