import pandas as pd
from numpy.random import random_sample
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score,confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

#read the data file
df = pd.read_csv("transaction_data.csv")
print(df.head(5))

#change the column name to DateTime from Timestamp
df.rename(columns={"Timestamp":"DateTime"},inplace=True)

#Indexnames check ofter rename process
column_names = df.columns
print(column_names)
print(df.head(5))

#split the one column into two columns
df[['Date', 'Time']] = df['DateTime'].str.split(' ', expand=True)
print(df[['DateTime']])
print(type(df[['DateTime']]))

# convert cat data  to num data
le = LabelEncoder()
for columns in ["Transaction Type","Transaction Amount","Transaction Status"]:
    df[columns] = le.fit_transform(df[columns])
    print(df[columns])

print("final_dataset:",df)

X = df[["Transaction Amount","Transaction Type"]]
y = df["Transaction Status"]
#import x,y values for test and train
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2,random_state=42)

# Define the random forest classifier
rf = RandomForestClassifier(n_estimators=10,random_state=42)
rf.fit(X_train, y_train)

# Make predictions on the test set
y_pred = rf.predict(X_test)
print("prediction:",y_pred)

# Evaluate the performance of the model
score = rf.score(X_test, y_test)
print("Accuracy:", score)

#Comfusion matrics
cm = confusion_matrix(y_test,y_pred)
print(cm)
#Visualation:
sns.heatmap(cm,annot=True,  cmap='Greens',fmt='b')
plt.xlabel('actual')
plt.ylabel('predict')
plt.title('Confusion Matrix')
plt.show()




