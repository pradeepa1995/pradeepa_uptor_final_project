import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules
from sklearn.preprocessing import OneHotEncoder,LabelEncoder

#declear the column name
column_names = ["city of new york","people and foods","value"]
df = pd.read_csv('Dataset.csv',names =column_names)
print(df.head())


#define the duplicate  values from features variables
duplicated_row= df.duplicated()
print(duplicated_row)
#define total sum of dataset
total_duplicated_row = df.duplicated().sum()
print(total_duplicated_row)


#define the df with only duplicates
final_df = df[df.duplicated()]
print(final_df)
#
#define the df without the duplicates

final_df = df[~df.duplicated()]
print(final_df)

final_df = df[~df.duplicated(keep=False)]
print(final_df)




#converting variables rows as "0" and "1"
one_hot_encoding_obj = OneHotEncoder(sparse_output=False)
final_hot_coded_data = one_hot_encoding_obj.fit_transform(df[["city of new york","people and foods","value"]].astype(str))
print(final_hot_coded_data)

#convert categorical data into numerical data
le = LabelEncoder()
for columns in ["city of new york","people and foods","value"]:
    df[columns] = le.fit_transform(df[columns])
    print(df[columns])



df["people and foods"] = df["people and foods"].apply(lambda x: 1 if x > 10 else 0)
print(df["people and foods"] )

df["city of new york"] = df["city of new york"].apply(lambda x: 1 if x > 10 else 0)
print(df["city of new york"] )

df["value"] = df["value"].apply(lambda x: 1 if x > 10 else 0)
print(df["value"] )

final_data_frame = pd.DataFrame(df)
print("final_data_frame:",final_data_frame)



# model prediction for freq_data
freq_items = apriori(final_data_frame, min_support=0.2, use_colnames=True, verbose=1)
print("freq_items:",freq_items.head())

# define the association rules
final_association = association_rules(freq_items,metric="confidence",min_threshold=0.6,num_itemsets=1)
print(final_association)


final_association.to_csv("data_output.csv")
#

for index, row in df.iterrows():
    print(row)
