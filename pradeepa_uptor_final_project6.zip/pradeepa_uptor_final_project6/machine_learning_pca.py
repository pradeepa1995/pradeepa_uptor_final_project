import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import  OneHotEncoder
from sklearn.preprocessing import LabelEncoder


# Load dataset
data =pd.read_csv("anxiety_depression_data.csv")
#
le =  LabelEncoder()
for columns in ["Gender","Education_Level","Employment_Status","Substance_Use","Medication_Use"]:
    data[columns] = le.fit_transform(data[columns])
    print(data[columns])

one_hot_encoding_obj = OneHotEncoder(sparse_output=False)
final_hot_coded_data = one_hot_encoding_obj.fit_transform(data[["Gender","Education_Level","Employment_Status","Substance_Use","Medication_Use"]])
print(final_hot_coded_data)

# Apply PCA to reduce dimensions to 2
pca = PCA(n_components=2)
X_pca = pca.fit_transform(data)

# Print PCA results
print("Original shape:", data.shape)
print("Reduced shape:", X_pca.shape)

# Display the transformed data
print("PCA Result:\n", X_pca[:10])